import javax.swing.*;
import javax.swing.table.JTableHeader;
import java.awt.*;

public class tablePanel extends JPanel {
    protected static MyTableModel dataModel = new MyTableModel();

    protected JTextField txtSum = new JTextField(10);;

    public tablePanel(){
        JTable t = new JTable(dataModel);
        JScrollPane scrollPane;
        setLayout(new BorderLayout());

        JTableHeader header = t.getTableHeader();
        header.setBackground(Color.yellow);
        scrollPane = new JScrollPane(t);

        scrollPane.setColumnHeaderView(t.getTableHeader());

        txtSum.setEditable(false);
        txtSum.setText("Total: ");

        add(scrollPane, BorderLayout.NORTH);
        add(txtSum, BorderLayout.CENTER);
    }
    public void editTextSum(){
        System.out.println(dataModel.getSum());
        txtSum.setText("Total: " + dataModel.getSum());
    }
}
