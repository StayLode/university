import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableRowSorter;
import javax.swing.text.TableView;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;


public class MyPanel extends JPanel {

    private JLabel lblDesc, lblAmount, lblDate;

    private JButton btnSearch, btnSubmit, btnNext;
    private JTextField txtSearch, txtResSearch, txtDesc, txtAmount, txtDate;
    private JComboBox cbType, cbList;

    private JRadioButton rbtnDef, rbtnDay, rbtnWeek, rbtnMonth, rbtnYear;
    private ButtonGroup bg;
    public MyPanel(){
        super();
        /**
         * Definizione Pannelli
         */
        JPanel mainP = new JPanel();
        JPanel pTable = new JPanel();
        pTable.setLayout(new BorderLayout());
        JPanel pEdit = new JPanel();
        pEdit.setLayout(new BorderLayout());
        JPanel pc1 = new JPanel();
        JPanel pc2 = new JPanel();
        JPanel pc3 = new JPanel();
        JPanel pEdit2 = new JPanel();
        pEdit2.setLayout(new BorderLayout());
        JPanel psSearch = new JPanel();
        JPanel psResult = new JPanel();
        mainP.setLayout(new BorderLayout());
        setLayout(new BorderLayout());

        /**
         * Definizione Tabella
         */
        /*
        tablePanel pTable = new tablePanel();
        managePanel pManage = new managePanel();*/

        MyTableModel dataModel= new MyTableModel();
        JTable t = new JTable(dataModel){
            public String getToolTipText( MouseEvent e )
            {
                int row = rowAtPoint( e.getPoint() );
                int column = columnAtPoint( e.getPoint() );

                Object value = getValueAt(row, column);
                return value == null ? null : value.toString();
            }
        };
        JTableHeader header = t.getTableHeader();
        header.setBackground(Color.yellow);
        TableRowSorter myTableRowSorter = new TableRowSorter(dataModel);
        t.setRowSorter(myTableRowSorter);
        t.setCellSelectionEnabled(true);
        JScrollPane scrollPane = new JScrollPane(t);
        //t.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        scrollPane.setColumnHeaderView(header);

        JTextField txtSum=new JTextField(10);
        txtSum.setEditable(false);
        txtSum.setText("Total: ");



        pTable.add(scrollPane, BorderLayout.NORTH);
        pTable.add(txtSum, BorderLayout.CENTER);
        pTable.add(pEdit, BorderLayout.SOUTH);

        lblDate = new JLabel("Date:");
        lblDesc = new JLabel("Description:");
        lblAmount = new JLabel("Amount:");
        txtDate = new JTextField(10);
        txtDate.setText(MyEntry.getLocalDate().toString());
        txtDesc = new JTextField(18);
        txtAmount = new JTextField(10);

        cbType = new JComboBox();
        cbType.addItem("Add");

        btnSubmit = new JButton("Submit") ;
        cbList = new JComboBox();
        cbList.setPreferredSize(new Dimension(300,25));


        /**
         * ActionListener per il ComboBox contenente le tipologie di azione sul conto
         * In questo modo, se selezionata la tipologia "Modify" e la voce della tabella,
         * verranno mostrati i valori nei rispettivi JTextField pronti ad essere modificati
         */

        cbList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (cbType.getSelectedItem().toString().equals("Modify") && cbList.getSelectedItem()!=null){
                    String[] splitted = cbList.getSelectedItem().toString().split(";");
                    String date = splitted[0].trim();
                    String desc = splitted[1].trim();
                    String amount = splitted[2].trim();
                    txtDate.setText(date);
                    txtDesc.setText(desc);
                    txtAmount.setText(amount);
                }

            }
        });
        pc1.add(lblDate);
        pc1.add(txtDate);
        pc1.add(lblAmount);
        pc1.add(txtAmount);
        pc1.add(lblDesc);
        pc1.add(txtDesc);
        pc2.add(cbType);
        pc2.add(cbList);
        pc2.add(btnSubmit);

        pEdit.add(pc1, BorderLayout.NORTH);
        pEdit.add(pc2, BorderLayout.CENTER);
        pEdit.add(pEdit2, BorderLayout.SOUTH);
        btnSubmit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                String amount;
                String desc;
                String date;
                switch(cbType.getSelectedItem().toString()) {
                    case "Add":
                        amount = txtAmount.getText();
                        desc = txtDesc.getText();
                        Data elem = new Data(desc, amount);
                        if (!elem.check()) {
                            txtDesc.setBorder(new LineBorder(Color.RED, 2));
                            txtAmount.setBorder(new LineBorder(Color.RED, 2));
                        } else {
                            date = txtDate.getText();
                            elem = new MyEntry(date, desc, amount);
                            if (!elem.check()) {
                                txtDate.setBorder(new LineBorder(Color.YELLOW, 2));
                                txtDate.setText(MyEntry.getLocalDate().toString());
                            } else {
                                if (dataModel.getRowCount()==0){
                                    cbType.addItem("Modify");
                                    cbType.addItem("Delete");
                                }
                                dataModel.addRow((MyEntry) elem);
                                String entryBox = txtDate.getText() + "; " + txtDesc.getText() + "; " + txtAmount.getText();
                                cbList.addItem(entryBox);
                                txtSum.setText("Total: " + dataModel.getSum());
                                resetTextField();
                            }
                        }break;
                    case "Modify":
                        amount = txtAmount.getText();
                        desc = txtDesc.getText();

                        String entry = cbList.getSelectedItem().toString();

                        int index = dataModel.get_index(entry);

                        elem = new Data(desc, amount);
                        if (!elem.check()) {
                            txtDesc.setBorder(new LineBorder(Color.RED, 2));
                            txtAmount.setBorder(new LineBorder(Color.RED, 2));
                        } else {
                            date = txtDate.getText();
                            elem = new MyEntry(date, desc, amount);
                            if (!elem.check()) {
                                txtDate.setBorder(new LineBorder(Color.YELLOW, 2));
                                txtDate.setText(MyEntry.getLocalDate().toString());
                            } else {
                                cbList.removeItem(entry); //Rimozione item da ComboBox
                                dataModel.modifyElem(index, date, desc, amount);
                                cbList.addItem(date + "; " + desc + "; " + amount); //Inserimento nuovo elemento nel ComboBox
                                resetTextField();
                                txtSum.setText("Total: " + dataModel.getSum());
                                dataModel.fireTableDataChanged();
                            }
                        }
                        break;
                    case "Delete":
                        entry = cbList.getSelectedItem().toString();
                        cbList.removeItem(entry);   //Rimozione item da Combobox
                        index = dataModel.get_index(entry);
                        dataModel.removeRow(index); //Rimozione elemento da tabella (vettore)

                        if(dataModel.getRowCount()==0){
                            cbType.removeItem("Modify");
                            cbType.removeItem("Delete");
                        }
                        txtSum.setText("Total: " + dataModel.getSum());
                        resetTextField();
                        dataModel.fireTableDataChanged();
                        break;
                }
            }
        });
/*
        JPanel pEdit = new JPanel();
        GroupLayout layout = new GroupLayout(pEdit);
        pEdit.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);
        layout.setHorizontalGroup(
                layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING))
                            .addComponent(lblDesc)
                            .addComponent(lblAmount)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING))
                            .addComponent(txtDesc)
                            .addComponent(txtAmount)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING))
                            .addComponent(lblDate)
                            .addComponent(btnSubmit)
                        .addComponent(txtDate)
        );
        layout.setHorizontalGroup(
                layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE))
                            .addComponent(lblDesc)
                            .addComponent(txtDesc)
                            .addComponent(lblDate)
                            .addComponent(txtDate)

                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE))
                            .addComponent(lblAmount)
                            .addComponent(txtAmount)
                            .addComponent(btnSubmit)
        );
*/

        bg = new ButtonGroup();
        rbtnDef = new JRadioButton("Default", true);
        rbtnDay = new JRadioButton("Day");
        rbtnWeek = new JRadioButton("Week");
        rbtnYear = new JRadioButton("Year");
        rbtnMonth = new JRadioButton("Month");
        rbtnDef.setHorizontalTextPosition(SwingConstants.LEFT);
        rbtnDay.setHorizontalTextPosition(SwingConstants.LEFT);
        rbtnWeek.setHorizontalTextPosition(SwingConstants.LEFT);
        rbtnYear.setHorizontalTextPosition(SwingConstants.LEFT);
        rbtnMonth.setHorizontalTextPosition(SwingConstants.LEFT);
        bg.add(rbtnDef);
        bg.add(rbtnDay);
        bg.add(rbtnWeek);
        bg.add(rbtnMonth);
        bg.add(rbtnYear);

        ActionListener rbtnActionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AbstractButton a =(AbstractButton)  e.getSource();
                myTableRowSorter.setRowFilter(new MyRowFilter(a.getText()));
                txtSum.setText("Total: " + dataModel.getSum());
            }
        };
        rbtnDay.addActionListener(rbtnActionListener);
        rbtnWeek.addActionListener(rbtnActionListener);
        rbtnMonth.addActionListener(rbtnActionListener);
        rbtnYear.addActionListener(rbtnActionListener);
        rbtnDef.addActionListener(rbtnActionListener);

        pc3.add(rbtnDef);
        pc3.add(rbtnDay);
        pc3.add(rbtnWeek);
        pc3.add(rbtnMonth);
        pc3.add(rbtnYear);



        pEdit2.add(pc3, BorderLayout.NORTH);

        /**
         * Ricerca di Informazioni nel bilancio
         */
        JPanel ps = new JPanel();


        txtSearch = new JTextField(20);

        btnSearch = new JButton("Search");
        btnNext = new JButton("Next");
        btnNext.setVisible(false);
        btnSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                rbtnDef.doClick();
                String occ=txtSearch.getText();
                int[] v= dataModel.getXY(occ);
                System.out.println(v[0]+" "+v[1]);
                if (v[0]!=-1 || v[1]!=-1) {
                        t.setColumnSelectionInterval(v[1], v[1]);
                        t.setRowSelectionInterval(v[0], v[0]);
                }

            }
        });

        psSearch.add(txtSearch);
        psSearch.add(btnSearch);
        psSearch.add(btnNext);

        pEdit2.add(psSearch, BorderLayout.CENTER);





        //mainP.add(, BorderLayout.NORTH);
        //mainP.add(pEdit, BorderLayout.CENTER);
        //mainP.add(ps, BorderLayout.SOUTH);
        add(pTable, BorderLayout.WEST);
    }


    public void resetTextField(){
        txtAmount.setText("");
        txtDate.setText(MyEntry.getLocalDate().toString());
        txtDesc.setText("");
        txtDate.setBorder(UIManager.getLookAndFeel().getDefaults().getBorder("TextField.border"));
        txtDesc.setBorder(UIManager.getLookAndFeel().getDefaults().getBorder("TextField.border"));
        txtAmount.setBorder(UIManager.getLookAndFeel().getDefaults().getBorder("TextField.border"));
    }



}
